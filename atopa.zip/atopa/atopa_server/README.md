# atopa-server

### Información

Una vez lanzado la aplicación estará accesible en localhost:8010.

### Instrucciones para uso.

En el directorio raíz (donde se encuentra el Makefile) ejecutar los siguientes comandos:

<pre>
make build
make up   #(La primera vez ejecutar dos veces)
</pre>