# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from rest_framework.authtoken.models import Token
from rest_framework.generics import get_object_or_404
from usuarios.models import User
from cuestionarios.models import Test, Preguntas_test
from resultados.models import Respuesta
from api.serializers import (UserSerializer,
                             TestSerializer,
                             PreguntasTestSerializer,
                             RespuestaSerializer,AuthCustomTokenSerializer)
from rest_framework import viewsets
from rest_framework.permissions import (IsAuthenticated,
                                        IsAuthenticatedOrReadOnly)
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from rest_framework.renderers import JSONRenderer

import logging
log = logging.getLogger(__name__)

class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    permission_classes = [IsAuthenticated]

    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer


class TestViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    permission_classes = [IsAuthenticated]

    queryset = Test.objects.all().order_by('nombre')
    serializer_class = TestSerializer


class PreguntasTestViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    permission_classes = [IsAuthenticated]

    queryset = Preguntas_test.objects.all().order_by('test_id')
    serializer_class = PreguntasTestSerializer


class RespuestaViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    permission_classes = [IsAuthenticated]
    serializer_class = RespuestaSerializer

    def get_queryset(self):
        queryset = Respuesta.objects.all()
        username = self.request.query_params.get('username', None)
        if username is not None:
            log.debug(username)
            student = User.objects.get(username=username)
            log.debug(student)
            queryset = queryset.filter(alumno=student)
            log.debug(queryset)
        return queryset


class TestView(APIView):
    permission_classes = [IsAuthenticated]
    def delete(self, request, name):
        test = get_object_or_404(Test.objects.all(), nombre=name)
        usersTest = User.test.through.objects.filter(test_id=test)
        for u in usersTest:
            student = User.objects.get(id=u.user_id)
            student.delete()
        test.delete()
        return Response({"message": "Test con nombre `{}` se ha borrado.".format(name)},status=204)

class ObtainAuthToken(APIView):
    throttle_classes = ()
    permission_classes = ()
    parser_classes = (
        FormParser,
        MultiPartParser,
        JSONParser,
    )

    renderer_classes = (JSONRenderer,)

    def post(self, request):
        serializer = AuthCustomTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)

        content = {
            'token': str(token.key),
        }

        return Response(content)