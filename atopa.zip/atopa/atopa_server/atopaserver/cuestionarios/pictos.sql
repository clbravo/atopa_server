insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzMzMDY0LnBuZw==', 'recreo');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzM0MTgucG5n', 'interrogacion');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzcwNjIucG5n', 'compañero');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzIxOTE3LnBuZw==', 'gustar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzIyMDA1LnBuZw==', 'no gustar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzY1MzcucG5n', 'jugar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzk4MTQucG5n', 'aula');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzI2MzY4LnBuZw==', 'rechazar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzg2NjIucG5n', 'pensar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzI0NzYzLnBuZw==', 'por que');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzU1MjYucG5n', 'no');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzExMjg3LnBuZw==', 'invitar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzY2MjUucG5n', 'tu');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzY5MDIucG5n', 'antipatico');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzEzMzU4LnBuZw==', 'quienes');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzExMTYzLnBuZw==', 'adivina');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzEwMjc2LnBuZw==', 'quien');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzU1MDgucG5n', 'mas');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzQ1NzAucG5n', 'ayudar');
insert into cuestionarios_pictos (link, name) values ('http://www.arasaac.org/classes/img/thumbnail.php?i=c2l6ZT0zMDAmcnV0YT0uLi8uLi9yZXBvc2l0b3Jpby9vcmlnaW5hbGVzLzI4NDU5LnBuZw==', 'molestar');

insert into cuestionarios_pictosquestions values (1,1,2,4);
insert into cuestionarios_pictosquestions values (2,2,4,4);
insert into cuestionarios_pictosquestions values (3,3,3,4);
insert into cuestionarios_pictosquestions values (4,4,7,4);

insert into cuestionarios_pictosquestions values (5,1,2,33);
insert into cuestionarios_pictosquestions values (6,2,11,33);
insert into cuestionarios_pictosquestions values (7,3,5,33);
insert into cuestionarios_pictosquestions values (8,4,3,33);
insert into cuestionarios_pictosquestions values (9,5,7,33);

insert into cuestionarios_pictosquestions values (10,1,2,57);
insert into cuestionarios_pictosquestions values (11,2,15,57);
insert into cuestionarios_pictosquestions values (12,3,9,57);
insert into cuestionarios_pictosquestions values (13,4,13,57);
insert into cuestionarios_pictosquestions values (14,5,6,57);

insert into cuestionarios_pictosquestions values (15,1,2,84);
insert into cuestionarios_pictosquestions values (16,2,15,84);
insert into cuestionarios_pictosquestions values (17,3,9,84);
insert into cuestionarios_pictosquestions values (18,4,8,84);
insert into cuestionarios_pictosquestions values (19,5,6,84);

insert into cuestionarios_pictosquestions values (20,1,16,112);
insert into cuestionarios_pictosquestions values (21,2,17,112);
insert into cuestionarios_pictosquestions values (22,3,18,112);
insert into cuestionarios_pictosquestions values (23,4,19,112);
insert into cuestionarios_pictosquestions values (24,5,3,112);

insert into cuestionarios_pictosquestions values (25,1,16,131);
insert into cuestionarios_pictosquestions values (26,2,17,131);
insert into cuestionarios_pictosquestions values (27,3,18,131);
insert into cuestionarios_pictosquestions values (28,4,20,131);
insert into cuestionarios_pictosquestions values (29,5,3,131);