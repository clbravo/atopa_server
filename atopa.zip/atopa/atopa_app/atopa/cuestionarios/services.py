import requests
import time
import json

from django.contrib.auth.hashers import make_password

from alumnos.models import Clase, Alumno
from cuestionarios.models import Preguntas_test, AlumnoTests, Test
from django.conf import settings 
import errno
from socket import error as socket_error

import logging
log = logging.getLogger(__name__)


def upload_to_server(cuestionario, form):

# ++++++++++++++++++ Obtencion de token ++++++++++++++++++++++++++++++

    username = form.cleaned_data['username']
    password = form.cleaned_data['password']
    result = requests.post(
        "https://{0}:{1}/api-token-auth/".format(settings.SERVER_IP, settings.SERVER_PORT),
        data={"username": username, "password": password},
        headers={'Accept': 'application/json'}, verify=False)
    if result.status_code != 200:
        return 1

    result_json = json.loads(result.content)
    token = result_json.get('token')

# +++++++++++++++++ Filtrado de los datos para subir al servidor +++++
    clase = Clase.objects.get(nombre=cuestionario.clase)
    alumnos = Alumno.objects.filter(clase_id=clase)
    preguntas = Preguntas_test.objects.filter(test=cuestionario)

# ++++++++++++++++ API ++++++++++++++++++++++++++++++++++++++++
# ++++++++++++++++ Crear test ++++++++++++++++++++++++++++++++++++


    result = requests.post(
        "https://{0}:{1}/api/tests/".format(settings.SERVER_IP, settings.SERVER_PORT),
        data={"nombre": cuestionario.nombre, "local_test": cuestionario.id},
        headers={'Accept': 'application/json',
                 'Authorization': 'Token {}'.format(token)}, verify=False)
    result_json = json.loads(result.content)
    test_server_id = result_json.get('id')

    cuestionario.remote_id = test_server_id
    cuestionario.save()

# ++++++++++++++++ Crear preguntas del test ++++++++++++++++++++++++++++++++++++


    for pregunta in preguntas:
        result = requests.post(
            "https://{0}:{1}/api/preguntastests/".format(settings.SERVER_IP, settings.SERVER_PORT),
            data={"test": test_server_id, "pregunta": pregunta.pregunta_id},
            headers={'Accept': 'application/json',
                     'Authorization': 'Token {}'.format(token)}, verify=False)

# +++++++++++++++++++ Crear alumnos +++++++++++++++++++++++++++++++++++++
    for alumno in alumnos:
        username = str(test_server_id) + str(alumno.id)
        password = make_password("api_user")
        result = requests.post(
            "https://{0}:{1}/api/users/".format(settings.SERVER_IP, settings.SERVER_PORT),
            data={"username": username, "nombre": alumno.nombre,
                  "apellidos": alumno.apellidos, "password": password,
                  "alias": alumno.alias, "test": test_server_id},
            headers={'Accept': 'application/json',
                     'Authorization': 'Token {}'.format(token)}, verify=False)
        al = AlumnoTests()
        al.username = username
        al.idAl = alumno
        al.idTest = cuestionario
        al.save()

    cuestionario.uploaded = True
    cuestionario.save()
    clase.modify = False
    clase.save()

def delete_from_server(cuestionario, form, delete):

    # ++++++++++++++++++ Obtencion de token ++++++++++++++++++++++++++++++

    username = form.cleaned_data['username']
    password = form.cleaned_data['password']
    result = requests.post(
        "https://{0}:{1}/api-token-auth/".format(settings.SERVER_IP, settings.SERVER_PORT),
        data={"username": username, "password": password},
        headers={'Accept': 'application/json'}, verify=False)

    if result.status_code != 200:
        return 1

    result_json = json.loads(result.content)
    token = result_json.get('token')

    requests.delete(
        "https://{0}:{1}/api/test/{2}".format(settings.SERVER_IP, settings.SERVER_PORT,cuestionario.nombre),
        headers={'Accept': 'application/json',
                 'Authorization': 'Token {}'.format(token)}, verify=False)

    if not delete:
        cuestionario.closed = True
        cuestionario.save()