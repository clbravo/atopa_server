# -*- coding: utf-8 -*-
from django import forms
import requests
from django.core.exceptions import ValidationError
from django.utils.translation import gettext
from django.conf import settings
import logging
import json
log = logging.getLogger(__name__)
class LoginUploadForm(forms.Form):
    username = forms.CharField(max_length=60)
    password = forms.CharField(max_length=20, widget=forms.PasswordInput)

    def __init__(self, *args, **kwargs):
        super(LoginUploadForm, self).__init__(*args, **kwargs)
        self.fields['username'].label = gettext('Usuario servidor')
        self.fields['password'].label = gettext('Contraseña servidor')

    def clean(self):
        cleaned_data = self.cleaned_data
        username = self.data['username']
        password = self.data['password']
        result = requests.post(
            "https://{0}:{1}/api-token-auth/".format(settings.SERVER_IP, settings.SERVER_PORT),
            data={"username": username, "password": password},
            headers={'Accept': 'application/json'}, verify=False)
        if result.status_code != 200:
            result_json = json.loads(result.content)
            raise ValidationError(result_json.get("non_field_errors")[0])
        return cleaned_data
